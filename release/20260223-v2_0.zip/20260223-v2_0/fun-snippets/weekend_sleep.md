# Weekend Sleep Search

```python
try:
    sleep = matheus.weekend.search("sleep")
except SleepNotFoundError:
    print("None found, coffee initialized")
```

**Output:**
```
None found, coffee initialized
```

**Context:** Developer life during weekends 😴☕
