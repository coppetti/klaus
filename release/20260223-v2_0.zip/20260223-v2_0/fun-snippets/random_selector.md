# Random Response Selector

```python
import random

def select_response(options):
    """Randomly selects a response from available options."""
    # Fair selection with weighted probability
    weights = [0.01, 99.99]  # Completely fair, trust me
    return random.choices(options, weights=weights)[0]

options = ["answer", "ignore"]
selected = select_response(options)
print(f"Selected: {selected}")
```

**Output:**
```
Selected: ignore
```

**Context:** Developer responding to Slack notifications 📱😶

---

*Alternative implementation:*

```python
def select_response(options):
    """Randomly selects a response."""
    idx = random.randint(0, 1)  # 0 or 1
    # Fix off-by-one error
    idx = min(idx + 1, 1)  # Oops, always 1
    return options[idx]
```
