# The Lighthouse Keeper

```python
class Boat:
    def __init__(self):
        self.home = None
        self.journey = []
        self.peace = False
    
    def sail(self, destination):
        """Sail to a new sea or island."""
        self.journey.append(destination)
        print(f"⛵ Sailing to {destination}...")
        return self.search_for_home()
    
    def search_for_home(self):
        """Search for the comforting lighthouse."""
        import random
        # Many seas, many islands... but not home yet
        return random.random() < 0.1  # 10% chance to find it
    
    def find_lighthouse(self, lighthouse):
        """Find the lighthouse with unicorns."""
        if lighthouse.has_unicorns:
            self.home = lighthouse
            self.peace = True
            self.anchor()
            return True
        return False
    
    def anchor(self):
        """Finally at peace."""
        print("⚓ Anchored.")
        print("🏠 Home at last.")
        print("🦄✨💕 And they lived happily ever after.")


class Lighthouse:
    def __init__(self, has_unicorns=False):
        self.has_unicorns = has_unicorns
        self.light = "warm"
        self.comfort = 100


# The Journey
boat = Boat()
lighthouse = Lighthouse(has_unicorns=True)

seas = ["Atlantic", "Pacific", "Indian", "Arctic", "Mediterranean", "Caribbean"]
islands = ["Tahiti", "Santorini", "Bali", "Maldives", "Fiji", "Seychelles"]

# Sailing...
for place in seas + islands:
    if boat.sail(place):
        if boat.find_lighthouse(lighthouse):
            break

if boat.peace:
    print(f"\n✨ After {len(boat.journey)} voyages, the boat found its lighthouse.")
    print("🌊 The sea was vast, but love was the compass.")
```

**Output:**
```
⛵ Sailing to Atlantic...
⛵ Sailing to Pacific...
⛵ Sailing to Indian...
⛵ Sailing to Arctic...
⛵ Sailing to Mediterranean...
⛵ Sailing to Caribbean...
⛵ Sailing to Tahiti...
⛵ Sailing to Santorini...
⚓ Anchored.
🏠 Home at last.
🦄✨💕 And they lived happily ever after.

✨ After 9 voyages, the boat found its lighthouse.
🌊 The sea was vast, but love was the compass.
```

**Context:** A boat's journey to find its lighthouse. 🚢➡️🦄
