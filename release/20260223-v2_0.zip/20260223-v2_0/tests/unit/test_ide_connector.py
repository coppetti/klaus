"""
Unit Tests - IDE Connector
==========================
"""

import sys
import os
import tempfile
import pytest
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.connectors.ide_connector import IDEConnector

class TestIDEConnector:
    """Test IDEConnector functionality."""
    
    @pytest.fixture
    def temp_workspace(self):
        """Create temporary workspace."""
        with tempfile.TemporaryDirectory() as tmpdir:
            workspace = Path(tmpdir) / "workspace"
            workspace.mkdir()
            
            # Create SOUL.md
            (workspace / "SOUL.md").write_text("# SOUL\\nTest agent")
            # Create USER.md
            (workspace / "USER.md").write_text("# USER\\nTest user")
            # Create init.yaml
            (workspace.parent / "init.yaml").write_text("""
agent:
  name: TestAgent
  template: general
user:
  name: TestUser
  role: Developer
""")
            
            yield workspace.parent
    
    def test_connector_loads_config(self, temp_workspace):
        """Test connector loads configuration."""
        os.chdir(temp_workspace)
        connector = IDEConnector()
        
        assert connector.agent_name == "TestAgent"
        assert connector.user_name == "TestUser"
    
    def test_get_context(self, temp_workspace):
        """Test context retrieval."""
        os.chdir(temp_workspace)
        connector = IDEConnector()
        
        context = connector.get_context("test message")
        
        # Should contain SOUL and USER
        assert "AGENT SOUL" in context or "SOUL" in context
        assert "USER PROFILE" in context or "USER" in context
    
    def test_store_interaction(self, temp_workspace):
        """Test storing interactions."""
        os.chdir(temp_workspace)
        connector = IDEConnector()
        
        # Store interaction
        connector.store_interaction("Question?", "Answer!")
        
        # Check it was stored
        memories = connector.recall("Question", limit=5)
        assert len(memories) > 0
    
    def test_store_fact(self, temp_workspace):
        """Test storing facts."""
        os.chdir(temp_workspace)
        connector = IDEConnector()
        
        connector.store_fact("User prefers Python", category="preference")
        
        memories = connector.recall("Python", limit=5)
        assert any("prefers" in m["content"] for m in memories)

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
