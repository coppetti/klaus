"""
Unit Tests - Memory Store
=========================
"""

import sys
import os
import tempfile
import pytest
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.memory import MemoryStore

class TestMemoryStore:
    """Test MemoryStore functionality."""
    
    @pytest.fixture
    def temp_db(self):
        """Create temporary database for testing."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        yield db_path
        # Cleanup
        os.unlink(db_path)
    
    @pytest.fixture
    def store(self, temp_db):
        """Create MemoryStore instance."""
        return MemoryStore(temp_db)
    
    def test_store_creation(self, temp_db):
        """Test database is created."""
        store = MemoryStore(temp_db)
        assert Path(temp_db).exists()
    
    def test_store_memory(self, store):
        """Test storing a memory."""
        memory_id = store.store(
            content="Test memory",
            category="test",
            importance="high"
        )
        assert memory_id > 0
    
    def test_recall_memory(self, store):
        """Test recalling memories."""
        # Store some memories
        store.store("Python is great", category="preference")
        store.store("I like Docker", category="preference")
        store.store("Random fact", category="general")
        
        # Recall
        results = store.recall("Python", limit=5)
        assert len(results) > 0
        assert any("Python" in r["content"] for r in results)
    
    def test_get_stats(self, store):
        """Test getting statistics."""
        store.store("Memory 1", category="test")
        store.store("Memory 2", category="test")
        
        stats = store.get_stats()
        assert stats["total"] == 2
        assert "test" in stats["categories"]
    
    def test_clear(self, store):
        """Test clearing all memories."""
        store.store("Memory to clear")
        store.clear()
        
        stats = store.get_stats()
        assert stats["total"] == 0
    
    def test_recall_keyword_scoring(self, store):
        """Test that keyword matching works."""
        store.store("Docker container running")
        store.store("Python script execution")
        store.store("Docker compose setup")
        
        # Should find Docker memories
        results = store.recall("Docker", limit=5)
        docker_memories = [r for r in results if "Docker" in r["content"]]
        assert len(docker_memories) >= 2

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
