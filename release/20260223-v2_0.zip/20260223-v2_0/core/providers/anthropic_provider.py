"""
Anthropic Provider
==================
Claude models via Anthropic API.
"""

import os
from typing import AsyncIterator, Dict, List, Optional, Any
import httpx
from .base import BaseProvider, Message, GenerationConfig, ProviderType

class AnthropicProvider(BaseProvider):
    """Anthropic Claude provider."""
    
    def __init__(self, api_key: str, model: str = "claude-3-5-sonnet-20241022", config: Dict = None):
        super().__init__(api_key, model, config)
        self.provider_type = ProviderType.ANTHROPIC
        self.base_url = "https://api.anthropic.com/v1"
        
    async def generate(
        self,
        messages: List[Message],
        config: Optional[GenerationConfig] = None
    ) -> AsyncIterator[str]:
        """Stream response from Claude."""
        config = config or GenerationConfig()
        
        # Separate system message
        system_msg = ""
        chat_messages = []
        
        for msg in messages:
            if msg.role == "system":
                system_msg = msg.content
            else:
                chat_messages.append({
                    "role": msg.role,
                    "content": msg.content
                })
        
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json"
        }
        
        payload = {
            "model": self.model,
            "messages": chat_messages,
            "max_tokens": config.max_tokens,
            "temperature": config.temperature,
            "top_p": config.top_p,
            "stream": True
        }
        
        if system_msg:
            payload["system"] = system_msg
        
        async with httpx.AsyncClient() as client:
            async with client.stream(
                "POST",
                f"{self.base_url}/messages",
                headers=headers,
                json=payload,
                timeout=120.0
            ) as response:
                async for line in response.aiter_lines():
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            break
                        try:
                            import json
                            chunk = json.loads(data)
                            if chunk.get("type") == "content_block_delta":
                                if delta := chunk.get("delta", {}).get("text"):
                                    yield delta
                        except json.JSONDecodeError:
                            continue
    
    async def generate_sync(
        self,
        messages: List[Message],
        config: Optional[GenerationConfig] = None
    ) -> str:
        """Non-streaming generation."""
        config = config or GenerationConfig()
        config.stream = False
        
        parts = []
        async for chunk in self.generate(messages, config):
            parts.append(chunk)
        return "".join(parts)
    
    def count_tokens(self, text: str) -> int:
        """Approximate token count."""
        # Claude uses ~4 chars per token on average
        return len(text) // 4
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get model information."""
        models = {
            "claude-3-opus-20240229": {
                "max_tokens": 200000,
                "description": "Most powerful Claude model"
            },
            "claude-3-5-sonnet-20241022": {
                "max_tokens": 200000,
                "description": "Balanced performance and speed"
            },
            "claude-3-haiku-20240307": {
                "max_tokens": 200000,
                "description": "Fastest Claude model"
            }
        }
        return models.get(self.model, {"max_tokens": 200000})
