"""
Tests for IDE Agent Wizard
==========================
Run with: python tests/run_tests.py
"""
