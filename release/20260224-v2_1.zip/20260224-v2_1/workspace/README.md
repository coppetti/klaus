# Workspace

This folder contains your data:
- SOUL.md - Agent identity (create via setup)
- USER.md - Your profile (create via setup)
- memory/ - SQLite database + Graph (auto-created)
- projects/ - Your projects (shared with containers)

