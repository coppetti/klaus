"""Unit tests for IDE Agent Wizard"""
