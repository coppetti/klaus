"""
Unit Tests for Hybrid Memory Store
==================================
Tests for SQLite + Graph hybrid memory system.
"""

import unittest
import tempfile
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from core.hybrid_memory import HybridMemoryStore, MemoryQuery


class TestHybridMemoryStore(unittest.TestCase):
    """Test cases for HybridMemoryStore."""
    
    def setUp(self):
        """Set up test database."""
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.temp_dir, "test_hybrid.db")
        self.memory = HybridMemoryStore(self.db_path)
    
    def tearDown(self):
        """Clean up test database."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_initialization(self):
        """Test HybridMemoryStore initialization."""
        self.assertIsNotNone(self.memory.sqlite)
        self.assertIsInstance(self.memory.graph_available, bool)
        # Graph might not be available in test environment
    
    def test_store_memory(self):
        """Test storing memory."""
        memory_id = self.memory.store(
            content="Test hybrid memory",
            category="test",
            importance="medium"
        )
        
        self.assertIsInstance(memory_id, int)
        self.assertGreater(memory_id, 0)
    
    def test_recall_quick(self):
        """Test quick recall from SQLite."""
        # Store memories
        self.memory.store("Python programming guide", category="programming")
        self.memory.store("JavaScript tutorial", category="programming")
        self.memory.store("Weather forecast", category="weather")
        
        # Quick search
        query = MemoryQuery(query_type="quick", text="Python", limit=5)
        results = self.memory.recall(query)
        
        self.assertIsInstance(results, list)
        # Should find Python-related memory
        found = any("Python" in str(r.get("content", "")) for r in results)
        self.assertTrue(found)
    
    def test_get_stats(self):
        """Test statistics retrieval."""
        # Store some memories
        self.memory.store("Memory 1", category="cat_a")
        self.memory.store("Memory 2", category="cat_b")
        
        stats = self.memory.get_stats()
        
        # Verify structure
        self.assertIn("sqlite", stats)
        self.assertIn("graph", stats)
        self.assertIn("graph_available", stats)
        self.assertIn("sync_queue_size", stats)
        
        # Verify sqlite stats
        self.assertIn("total", stats["sqlite"])
        self.assertEqual(stats["sqlite"]["total"], 2)
    
    def test_api_compatibility(self):
        """Test that API is compatible with expected usage."""
        # This tests the fix for IDEConnector.recall() compatibility
        query = MemoryQuery(query_type="quick", text="test", limit=5)
        results = self.memory.recall(query)
        
        # Should not raise TypeError
        self.assertIsInstance(results, list)
    
    def test_background_sync_queue(self):
        """Test background sync queue."""
        # Initially queue should be empty
        self.assertEqual(len(self.memory._sync_queue), 0)
        
        # Store memory - should add to queue if graph available
        self.memory.store("Test for queue", category="test")
        
        # Queue might have item if graph is available
        # Just verify it doesn't crash
        self.assertIsInstance(self.memory._sync_queue, list)
    
    def test_memory_query_creation(self):
        """Test MemoryQuery dataclass."""
        query = MemoryQuery(
            query_type="context",
            text="test query",
            limit=10,
            context_depth=3
        )
        
        self.assertEqual(query.query_type, "context")
        self.assertEqual(query.text, "test query")
        self.assertEqual(query.limit, 10)
        self.assertEqual(query.context_depth, 3)


class TestMemoryQuery(unittest.TestCase):
    """Test MemoryQuery dataclass."""
    
    def test_default_values(self):
        """Test default values."""
        query = MemoryQuery(query_type="quick", text="test")
        
        self.assertEqual(query.limit, 5)  # Default
        self.assertEqual(query.context_depth, 2)  # Default
    
    def test_custom_values(self):
        """Test custom values."""
        query = MemoryQuery(
            query_type="semantic",
            text="custom query",
            limit=20,
            context_depth=5
        )
        
        self.assertEqual(query.query_type, "semantic")
        self.assertEqual(query.text, "custom query")
        self.assertEqual(query.limit, 20)
        self.assertEqual(query.context_depth, 5)


if __name__ == "__main__":
    unittest.main()
