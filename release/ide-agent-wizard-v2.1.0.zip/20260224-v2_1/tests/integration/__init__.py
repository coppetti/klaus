"""Integration tests for IDE Agent Wizard"""
