# ⚡ Quick Start - Ultra Low-Code

> Crie seu primeiro agente em **2 minutos** sem escrever código.

---

## 🚀 Método Ultra Rápido (YAML Only)

### Passo 1: Configurar GCP (30 segundos)
```bash
gcloud auth login
gcloud auth application-default login
export GOOGLE_CLOUD_PROJECT=seu-projeto-id
```

### Passo 2: Editar Agente (30 segundos)
```bash
# Edite o arquivo YAML existente
vim agents/meu_assistente.yaml

# Mude apenas o 'instruction' para o que quiser
# Salve (Ctrl+O, Enter, Ctrl+X no nano)
```

### Passo 3: Validar (10 segundos)
```bash
python src/agent_builder/ultra_lowcode.py validate agents/meu_assistente.yaml
```

**Esperado:** ✅ Configuração válida!

### Passo 4: Rodar (1 minuto)
```bash
python src/agent_builder/ultra_lowcode.py run agents/meu_assistente.yaml
```

**Pronto!** Chat interativo iniciado. Digite `sair` para encerrar.

---

## 📁 Agente Já Incluídos

| Arquivo | Tipo | Descrição |
|---------|------|-----------|
| `meu_assistente.yaml` | Simples | Assistente geral amigável |
| `router_atendimento.yaml` | Router | Direciona para vendas/suporte/financeiro |
| `vendas.yaml` | Especialista | Vendas e negociações |
| `suporte.yaml` | Especialista | Suporte técnico |
| `financeiro.yaml` | Especialista | Faturas e pagamentos |

---

## 🔄 Workflow Comum

```bash
# 1. Copie um template
cp agents/meu_assistente.yaml agents/meu_novo.yaml

# 2. Edite (use qualquer editor de texto)
# Mude: name, description, instruction

# 3. Valide
python src/agent_builder/ultra_lowcode.py validate agents/meu_novo.yaml

# 4. Teste
python src/agent_builder/ultra_lowcode.py run agents/meu_novo.yaml

# 5. Quando satisfeito, "compile" para deploy
python src/agent_builder/ultra_lowcode.py compile agents/meu_novo.yaml
eab deploy --agent meu_novo
```

---

## 💡 Exemplo Completo

### Criar Agente de RH

```bash
# 1. Criar arquivo
cat > agents/rh_assistente.yaml << 'EOF'
name: rh_assistente
type: llm
model: gemini-2.0-flash-exp

description: Assistente do RH para dúvidas de funcionários

instruction: |
  Você é o assistente virtual do RH.
  
  ÁREAS DE CONHECIMENTO:
  - Políticas de férias e folgas
  - Benefícios (plano de saúde, VA/VR, etc)
  - Processos internos
  - Normas CLT (básico)
  
  REGRAS:
  1. Seja empático e discreto
  2. Para dados pessoais, oriente acessar portal
  3. Nunca forneça informações de outros funcionários
  4. Casos sensíveis: sugira falar direto com RH
  
  TOM: Profissional, acolhedor, claro.

tools:
  - google_search

temperature: 0.5
EOF

# 2. Validar
python src/agent_builder/ultra_lowcode.py validate agents/rh_assistente.yaml

# 3. Testar
python src/agent_builder/ultra_lowcode.py run agents/rh_assistente.yaml
```

**Pronto!** Seu agente de RH está funcionando.

---

## 🆚 Comparação de Esforço

| Tarefa | Python Tradicional | Ultra Low-Code |
|--------|-------------------|----------------|
| Criar agente | 30 min | 2 min |
| Linhas escritas | ~30 linhas | ~15 linhas YAML |
| Syntax errors | Comuns | Raros (YAML simples) |
| Curva aprendizado | Média | Mínima |
| Deploy | Multi-step | `eab deploy` |

---

## 🎯 Próximos Passos

1. ✅ Teste os agentes incluídos
2. ✅ Crie um agente customizado
3. ✅ Conecte com Bibha.ai (via adapter)
4. ✅ Deploy para produção

---

**Pronto para começar? Execute:**
```bash
export GOOGLE_CLOUD_PROJECT=seu-projeto
python src/agent_builder/ultra_lowcode.py run agents/meu_assistente.yaml
```
