# Guia de Integração Bibha.ai (Documentação Real)

## 📋 Resumo da API Bibha.ai

Baseado na documentação oficial, a Bibha.ai expõe uma API REST compatível com integrações externas.

### Autenticação
```
Authorization: Bearer bah-sk-your-api-key
```

### Endpoint Principal
```
POST /api/v1/prediction/{chatflowId}
```

### Request Format
```json
{
  "question": "Mensagem do usuário",
  "sessionId": "sessao-unica-id",
  "overrideConfig": {
    "temperature": 0.7
  }
}
```

### Response Format
```json
{
  "text": "Resposta do agente",
  "chatId": "chat-abc123",
  "chatMessageId": "msg-xyz789",
  "sourceDocuments": []
}
```

---

## 🏗️ Arquitetura de Integração

```
┌─────────────────────────────────────────────────────────────────┐
│  Canais (WhatsApp, Web, etc)                                    │
└─────────────────────────┬───────────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────────┐
│  Bibha.ai AgentsHub                                             │
│  - Orquestração de canais                                       │
│  - Gestão de sessões                                            │
│  - Routing entre agentes                                        │
└─────────────────────────┬───────────────────────────────────────┘
                          │ HTTP Tool / Webhook
                          │ POST /api/v1/prediction/{chatflowId}
┌─────────────────────────▼───────────────────────────────────────┐
│  Easy Agent Builder Adapter                                     │
│  - Recebe requests Bibha                                        │
│  - Processa via ADK                                             │
│  - Retorna formato Bibha                                        │
└─────────────────────────┬───────────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────────┐
│  Agente ADK (Google/Gemini)                                     │
│  - Processamento LLM                                            │
│  - Tools customizadas                                           │
│  - RAG (opcional)                                               │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🚀 Setup Passo a Passo

### 1. Obter Credenciais da Bibha

No dashboard da Bibha.ai:
1. Acesse **Utils → API Keys**
2. Clique **"Create API Key"**
3. Copie a chave (formato: `bah-sk-...`)
4. Anote o **chatflowId** que deseja integrar

### 2. Configurar Variáveis de Ambiente

```bash
# .env
BIBHA_API_KEY=bah-sk-sua-chave-aqui
BIBHA_API_HOST=https://sua-instancia.bibha.ai
BIBHA_CHATFLOW_ID=seu-chatflow-id
```

### 3. Criar Agente ADK

```yaml
# agents/vendas_integrado.yaml
name: vendedor_integrado
type: llm
model: gemini-2.0-flash-exp

description: Vendedor integrado ao Bibha AgentsHub

instruction: |
  Você é um vendedor B2B. Este agente é acessado via Bibha.ai.
  
  Sua função é qualificar leads e direcionar para o time comercial.

tools:
  - google_search

temperature: 0.7
```

### 4. Deploy do Adapter

```bash
# Deploy para Cloud Run
gcloud run deploy bibha-adapter \
  --source . \
  --set-env-vars BIBHA_API_KEY=bah-sk-xxx \
  --set-env-vars BIBHA_API_HOST=https://xxx.bibha.ai \
  --set-env-vars BIBHA_CHATFLOW_ID=xxx
```

### 5. Configurar HTTP Tool na Bibha

No Bibha AgentsHub:

1. Acesse **Utils → Toolkit**
2. Clique **"Add Tool"**
3. Configure:

**Nome:** `ADK Agent Bridge`

**Method:** `POST`

**URL:** `https://seu-adapter-url.run.app/api/v1/prediction/{{chatflowId}}`

**Headers:**
```json
{
  "Content-Type": "application/json"
}
```

**Body:**
```json
{
  "question": "{{user_message}}",
  "sessionId": "{{session_id}}",
  "chatflowId": "{{chatflow_id}}",
  "metadata": {
    "channel": "{{channel}}",
    "user_id": "{{user_id}}"
  }
}
```

### 6. Testar

No chat da Bibha, envie uma mensagem. Ela será:
1. Recebida pela Bibha
2. Encaminhada para seu adapter
3. Processada pelo agente ADK
4. Retornada ao usuário

---

## 🔧 Endpoints do Adapter

### POST /api/v1/prediction/{chatflowId}
Endpoint compatível com API Bibha. Recebe mensagens e retorna respostas.

### POST /webhook/bibha
Endpoint alternativo para webhooks.

### GET /health
Health check para monitoramento.

---

## 📊 Mapeamento de Dados

### Bibha → ADK
| Campo Bibha | Campo ADK | Descrição |
|-------------|-----------|-----------|
| `question` | `new_message` | Mensagem do usuário |
| `sessionId` | `session_id` | ID da sessão |
| `chatflowId` | `app_name` | Contexto do chatflow |
| `metadata` | `state` | Dados adicionais |

### ADK → Bibha
| Campo ADK | Campo Bibha | Descrição |
|-----------|-------------|-----------|
| `content` | `text` | Resposta do agente |
| `session_id` | `sessionId` | Manter sessão |
| `sourceDocuments` | `sourceDocuments` | RAG sources |

---

## 🔄 Fluxo Completo

```
1. Usuário envia mensagem no WhatsApp (via Bibha)
   → "Olá, quero saber preços"

2. Bibha recebe e chama HTTP Tool
   POST /api/v1/prediction/vendas-flow
   {
     "question": "Olá, quero saber preços",
     "sessionId": "sess-123"
   }

3. Adapter recebe e processa
   - Cria sessão ADK
   - Executa agente
   - Coleta resposta

4. Adapter retorna para Bibha
   {
     "text": "Olá! Fico feliz em ajudar...",
     "sessionId": "sess-123"
   }

5. Bibha exibe resposta ao usuário no WhatsApp
```

---

## 🛠️ Customização

### Adicionar Metadados

Você pode passar informações extras da Bibha para o ADK:

```json
{
  "question": "{{user_message}}",
  "sessionId": "{{session_id}}",
  "metadata": {
    "channel": "whatsapp",
    "user_phone": "{{phone}}",
    "campaign": "black-friday-2024"
  }
}
```

No agente ADK, acesse via `session.state`.

### Session Management

A Bibha envia `sessionId` para manter contexto. O adapter:
1. Usa o mesmo `sessionId` no ADK
2. Persiste estado entre mensagens
3. Permite conversas contínuas

---

## 🚨 Troubleshooting

### Erro 401 - Unauthorized
```
Verifique: BIBHA_API_KEY está configurada corretamente?
```

### Erro 404 - Chatflow não encontrado
```
Verifique: O chatflowId existe na Bibha?
```

### Timeout
```
Bibha tem timeout padrão. Respostas devem ser < 30s.
Para processamento longo, use webhooks assíncronos.
```

### Sessão não persiste
```
Verifique se sessionId está sendo passado corretamente
nos requests da Bibha para o adapter.
```

---

## 📚 Recursos

- **Código:** `examples/10_bibha_integration_real.py`
- **Adapter:** `src/agent_builder/bibha_adapter_real.py`
- **API Bibha Docs:** `BIBHA_AGENTSHUB_USER_GUIDE_COMPLETE.html`

---

## ✅ Checklist de Integração

- [ ] API Key da Bibha gerada
- [ ] Chatflow ID identificado
- [ ] Adapter deployado
- [ ] HTTP Tool configurado na Bibha
- [ ] Teste de mensagem funcionando
- [ ] Session persistence validado
- [ ] Logs monitorando erros

---

**Pronto para integrar!** 🚀
