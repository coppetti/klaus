# Guia de Integração com Orquestradores Externos

## Visão Geral

Este framework foi projetado para facilitar integração com orquestradores externos
como **Bibha.ai**, **Voiceflow**, **Stack AI**, ou qualquer plataforma que suporte
webhooks HTTP.

A arquitetura é **completamente desacoplada** - você implementa apenas os
adaptadores específicos sem modificar o core.

---

## Arquitetura de Integração

```
┌─────────────────────────────────────────────────────────────────┐
│  Orquestrador Externo (Bibha.ai)                                │
│  - Gerencia conversação                                         │
│ - Controla fluxo de alto nível                                  │
│ - Mantém contexto de negócio                                    │
└────────────────────────┬────────────────────────────────────────┘
                         │ HTTP/Webhook
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│  Seu Adapter (você implementa)                                  │
│  - Autenticação                                                 │
│  - Mapeamento de request/response                               │
│  - Sincronização de contexto                                    │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│  Easy Agent Builder (genérico)                                  │
│  - ExternalOrchestratorAdapter (base)                           │
│  - Agent execution (ADK)                                        │
│  - Session management                                           │
└─────────────────────────────────────────────────────────────────┘
```

---

## Implementação Passo a Passo

### Passo 1: Entender a API do Orquestrador

Antes de codificar, você precisa saber:

| Aspecto | O que perguntar | Exemplo de resposta |
|---------|-----------------|---------------------|
| **Autenticação** | Como autenticar requests? | API Key no header X-API-Key |
| **Request Format** | Qual o schema do webhook? | `{message, session_id, user_id}` |
| **Response Format** | O que retornar? | `{text, actions, transfer_to}` |
| **Session** | Como gerenciar contexto? | Session ID + context object |
| **Rate Limits** | Limites de requisição? | 100 req/min |

### Passo 2: Criar Adapter Privado

```python
# arquivo: private/bibha_adapter.py (não commite!)
from agent_builder.integration_abstract import (
    ExternalOrchestratorAdapter,
    AgentRequest,
    AgentResponse,
)

class BibhaAdapter(ExternalOrchestratorAdapter):
    
    def _authenticate(self, request: Request) -> bool:
        # Implemente conforme doc real
        pass
    
    def _map_incoming_request(self, raw_request: dict) -> AgentRequest:
        # Mapeie campos específicos da Bibha
        pass
    
    def _map_outgoing_response(self, response: AgentResponse, ...) -> dict:
        # Formate para o que Bibha espera
        pass
```

### Passo 3: Configurar Sem Hardcode

Use **variáveis de ambiente** para configurações:

```bash
# .env (não commite!)
BIBHA_API_KEY=sk_live_xxx
BIBHA_WEBHOOK_SECRET=whsec_xxx
BIBHA_MESSAGE_FIELD=conversation.text
BIBHA_SESSION_FIELD=session.id
```

```python
# No adapter
import os

class BibhaAdapter(ExternalOrchestratorAdapter):
    def __init__(self, agent, ...):
        super().__init__(agent, ...)
        self.api_key = os.getenv("BIBHA_API_KEY")
        self.message_field = os.getenv("BIBHA_MESSAGE_FIELD", "message")
```

### Passo 4: Deploy

```bash
# Deploy sem expor código privado
gcloud run deploy agent-adapter \
    --source . \
    --set-env-vars "BIBHA_API_KEY=$(cat /secrets/bibha_key)"
```

---

## Padrões Comuns de Mapeamento

### 1. Request Simples

**Orquestrador envia:**
```json
{
  "message": "Quero saber meu saldo",
  "session_id": "sess_abc123",
  "user_id": "user_456",
  "metadata": {"channel": "whatsapp"}
}
```

**Seu mapeamento:**
```python
def _map_incoming_request(self, raw: dict) -> AgentRequest:
    return AgentRequest(
        message=raw["message"],
        session_id=raw["session_id"],
        user_id=raw["user_id"],
        metadata=raw.get("metadata", {})
    )
```

### 2. Response com Actions

**Seu agente retorna:**
```python
AgentResponse(
    message="Seu saldo é R$ 1.000",
    actions=[
        {"type": "button", "label": "Ver extrato", "value": "extrato"},
        {"type": "button", "label": "Transferir", "value": "transferencia"}
    ]
)
```

**Mapeamento para orquestrador:**
```python
def _map_outgoing_response(self, response: AgentResponse, ...) -> dict:
    return {
        "text": response.message,
        "suggestions": response.actions,  # Bibha pode usar este campo
        "session_id": response.session_id
    }
```

### 3. Transferência entre Agentes

Se Bibha suporta transferência para outros agentes:

```python
def _map_outgoing_response(self, response: AgentResponse, ...) -> dict:
    result = {
        "text": response.message,
        "session_id": response.session_id
    }
    
    # Se seu agente detectou necessidade de transferência
    if response.transfer_to:
        result["transfer"] = {
            "to_agent": response.transfer_to,
            "reason": "Especialização necessária",
            "context": response.context
        }
    
    return result
```

---

## Checklist de Integração

Antes de ir para produção:

- [ ] **Autenticação**: Requests são validados corretamente?
- [ ] **Mapeamento**: Todos os campos são mapeados corretamente?
- [ ] **Session**: Contexto persiste entre chamadas?
- [ ] **Error Handling**: Erros são tratados e logados?
- [ ] **Rate Limiting**: Respeita limites da API externa?
- [ ] **Timeout**: Requests não travam indefinidamente?
- [ ] **Secrets**: Nenhum secret hardcoded no código?
- [ ] **Logs**: Não loga dados sensíveis (PII)?

---

## Troubleshooting

### Problema: Request chega mas agente não responde

```python
# Adicione logging no adapter
def _map_incoming_request(self, raw: dict) -> AgentRequest:
    print(f"DEBUG - Raw request: {raw}")  # Remova em produção
    
    request = AgentRequest(...)
    print(f"DEBUG - Mapped request: {request}")
    return request
```

### Problema: Formatos incompatíveis

Use uma **camada de transformação**:

```python
def _transform_message(self, raw_msg: dict) -> str:
    """Lida com diferentes formatos de mensagem."""
    if isinstance(raw_msg, str):
        return raw_msg
    if isinstance(raw_msg, dict):
        return raw_msg.get("text") or raw_msg.get("content", "")
    return str(raw_msg)
```

### Problema: Session não persiste

Verifique:
1. SessionStore está configurado? (Redis vs In-Memory)
2. Session ID é passado corretamente?
3. TTL não expirou muito rápido?

---

## Alternativas de Integração

Se Bibha.ai não tiver API direta, considere:

### Opção A: Webhook Genérico (Zapier/Make)
Bibha → Zapier → Seu endpoint HTTP

### Opção B: Custom Integration
Desenvolver microserviço intermediário

### Opção C: Full Migration
Gradualmente mover para ADK nativo

---

## Recursos

- [ADK Documentation](https://google.github.io/adk-docs/)
- [FastAPI Webhooks Guide](https://fastapi.tiangolo.com/advanced/security/http-basic-auth/)
- [Webhook Security Best Practices](https://webhook.site/)

---

**Dúvidas sobre implementação específica?** 
Consulte a documentação privada da API e adapte os templates fornecidos.
