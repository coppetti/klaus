#!/bin/bash
#
# Script de setup para teste local
# Execute: chmod +x setup_test.sh && ./setup_test.sh
#

set -e  # Exit on error

echo "🚀 Easy Agent Builder - Setup para Teste Local"
echo "================================================"
echo ""

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Verificar Python
if ! command -v python3.11 &> /dev/null; then
    echo -e "${RED}❌ Python 3.11 não encontrado${NC}"
    echo "   Instale Python 3.11: https://www.python.org/downloads/"
    exit 1
fi

echo -e "${GREEN}✅ Python 3.11 encontrado${NC}"

# Verificar gcloud
if ! command -v gcloud &> /dev/null; then
    echo -e "${YELLOW}⚠️  gcloud CLI não encontrado${NC}"
    echo "   Instale: https://cloud.google.com/sdk/docs/install"
fi

# Criar virtual environment
echo ""
echo "📦 Criando ambiente virtual..."
if [ -d "venv" ]; then
    echo "   venv já existe, usando existente"
else
    python3.11 -m venv venv
    echo -e "${GREEN}✅ Ambiente virtual criado${NC}"
fi

# Ativar
source venv/bin/activate

# Instalar dependências
echo ""
echo "📥 Instalando dependências..."
pip install -q --upgrade pip
pip install -q -e ".[dev]"
echo -e "${GREEN}✅ Dependências instaladas${NC}"

# Verificar autenticação GCP
echo ""
echo "🔐 Verificando autenticação GCP..."

if gcloud auth print-access-token &> /dev/null; then
    PROJECT=$(gcloud config get-value project 2>/dev/null)
    echo -e "${GREEN}✅ Autenticado no GCP${NC}"
    echo "   Projeto: $PROJECT"
else
    echo -e "${YELLOW}⚠️  Não autenticado no GCP${NC}"
    echo "   Execute: gcloud auth login"
    echo "   Ou: gcloud auth application-default login"
fi

# Criar agente de exemplo se não existir
if [ ! -d "src/agents/meu_chatbot" ]; then
    echo ""
    echo "🤖 Criando agente de exemplo..."
    eab create agent meu_chatbot --type llm --tools google_search
    
    # Personalizar agente
    cat > src/agents/meu_chatbot/agent.py << 'PYEOF'
"""
Meu Chatbot - Agente simples com Vertex AI.
"""

from google.adk.agents import LlmAgent
from google.adk.tools import google_search

agent = LlmAgent(
    model="gemini-2.0-flash-exp",
    name="meu_chatbot",
    description="Um chatbot amigável e prestativo",
    instruction="""
    Você é um assistente virtual amigável.
    Responda em português do Brasil.
    Seja cordial, direto e útil.
    """,
    tools=[google_search],
)

__all__ = ["agent"]
PYEOF
    
    echo -e "${GREEN}✅ Agente 'meu_chatbot' criado${NC}"
else
    echo -e "${GREEN}✅ Agente 'meu_chatbot' já existe${NC}"
fi

# Criar .env de exemplo
echo ""
echo "📝 Criando arquivo de configuração..."
if [ ! -f ".env" ]; then
    cat > .env << 'ENVEOF'
# Configure suas variáveis
GOOGLE_CLOUD_PROJECT=seu-projeto-aqui
GOOGLE_CLOUD_LOCATION=us-central1

# Opcional: se usar service account
# GOOGLE_APPLICATION_CREDENTIALS=/path/to/key.json
ENVEOF
    echo -e "${YELLOW}⚠️  Edite o arquivo .env com seu projeto GCP${NC}"
else
    echo -e "${GREEN}✅ Arquivo .env já existe${NC}"
fi

# Resumo
echo ""
echo "================================================"
echo -e "${GREEN}✅ Setup completo!${NC}"
echo ""
echo "Próximos passos:"
echo ""
echo "1. Configure o projeto GCP:"
echo "   export GOOGLE_CLOUD_PROJECT=seu-projeto"
echo "   # ou edite o arquivo .env"
echo ""
echo "2. Teste local:"
echo "   python test_local.py"
echo ""
echo "3. Ou use o CLI:"
echo "   eab list"
echo "   eab test meu_chatbot"
echo ""
echo "4. Para deploy:"
echo "   eab deploy --agent meu_chatbot"
echo ""
