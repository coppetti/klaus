"""
Script de teste local - Chatbot simples com Vertex AI.
"""

import asyncio
import os
import sys

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

# Configurar GCP (substitua ou use env vars)
os.environ.setdefault("GOOGLE_CLOUD_PROJECT", "seu-projeto-aqui")
os.environ.setdefault("GOOGLE_CLOUD_LOCATION", "us-central1")

# Verificar configuração
if os.environ["GOOGLE_CLOUD_PROJECT"] == "seu-projeto-aqui":
    print("⚠️  ATENÇÃO: Configure GOOGLE_CLOUD_PROJECT no código ou variável de ambiente")
    print("   export GOOGLE_CLOUD_PROJECT=seu-projeto-id")
    print()
    sys.exit(1)

print("🔄 Inicializando...")
print(f"   Projeto: {os.environ['GOOGLE_CLOUD_PROJECT']}")
print(f"   Location: {os.environ['GOOGLE_CLOUD_LOCATION']}")
print()

try:
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService
except ImportError as e:
    print(f"❌ Erro ao importar ADK: {e}")
    print("   Execute: pip install google-adk")
    sys.exit(1)

# Importar agente (crie primeiro com: eab create agent meu_chatbot --type llm)
try:
    from agents.meu_chatbot.agent import agent
except ImportError:
    print("❌ Agente não encontrado!")
    print()
    print("💡 Crie o agente primeiro:")
    print("   eab create agent meu_chatbot --type llm")
    print()
    print("   Ou edite este script para importar outro agente:")
    print("   from agents.NOME_DO_AGENTE.agent import agent")
    sys.exit(1)


async def chat():
    """Chat interativo."""
    # Setup
    session_service = InMemorySessionService()
    runner = Runner(agent=agent, session_service=session_service)
    
    # Criar sessão
    session = session_service.create_session(
        app_name=agent.name,
        user_id="user_test"
    )
    
    print(f"🤖 {agent.name} iniciado!")
    print(f"   Descrição: {agent.description}")
    print(f"   Modelo: {agent.model}")
    print()
    print("Digite 'sair' para encerrar.\n")
    
    while True:
        try:
            # Input
            user_input = input("👤 Você: ").strip()
            
            if not user_input:
                continue
                
            if user_input.lower() in ["sair", "exit", "quit", "q"]:
                print("\n👋 Até logo!")
                break
            
            # Executar
            print("🤖 Agente: ", end="", flush=True)
            
            full_response = []
            async for event in runner.run_async(
                user_id="user_test",
                session_id=session.id,
                new_message=user_input
            ):
                # Tentar extrair texto
                text = None
                if hasattr(event, 'content') and event.content:
                    text = str(event.content)
                elif hasattr(event, 'text') and event.text:
                    text = str(event.text)
                elif hasattr(event, 'partial_text') and event.partial_text:
                    text = str(event.partial_text)
                
                if text:
                    full_response.append(text)
                    # Se for evento final, mostra
                    if hasattr(event, 'is_final') and event.is_final:
                        print(text)
            
            # Se não mostrou nada ainda, mostra último
            if full_response and not any("Agente:" in line for line in full_response):
                print(full_response[-1])
            elif not full_response:
                print("(sem resposta)")
            
            print()
            
        except KeyboardInterrupt:
            print("\n\n👋 Interrompido!")
            break
        except Exception as e:
            print(f"\n❌ Erro: {e}")
            import traceback
            traceback.print_exc()


if __name__ == "__main__":
    try:
        asyncio.run(chat())
    except Exception as e:
        print(f"\n❌ Erro fatal: {e}")
        sys.exit(1)
