# Arquitetura de Integração: Easy Agent Builder + Bibha.ai

## 🎯 Visão Geral

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         COMO TUDO SE CONECTA                                 │
└─────────────────────────────────────────────────────────────────────────────┘

USUÁRIO FINAL
     │
     │ WhatsApp / Web / Telefone
     ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  BIBHA.AI AGENTSHUB (Orquestradora Externa)                                 │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  • Recebe mensagens de múltiplos canais                             │   │
│  │  • Gerencia sessões de conversação                                  │   │
│  │  • Roteia entre agentes internos OU externos                        │   │
│  │  • Mantém contexto da conversa                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│     Quando necessário, chama:      │                                        │
│     HTTP Tool / Webhook            │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  HTTP Tool Configurado:                                             │   │
│  │  POST https://nosso-adapter.run.app/api/v1/prediction/{chatflowId} │   │
│  │  {                                                                  │   │
│  │    "question": "mensagem do usuário",                               │   │
│  │    "sessionId": "sess-123-abc",                                     │   │
│  │    "metadata": {...}                                                │   │
│  │  }                                                                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ Internet (HTTPS)
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  EASY AGENT BUILDER ADAPTER (Nosso código - GCP Cloud Run)                  │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  FastAPI Endpoint:                                                  │   │
│  │  • POST /api/v1/prediction/{chatflowId}  ← Recebe da Bibha          │   │
│  │  • POST /webhook/bibha                   ← Alternativa            │   │
│  │  • GET /health                           ← Monitoramento          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│     Processa:                      │                                        │
│     • Mapeia request Bibha → ADK   │                                        │
│     • Executa agente               ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  GOOGLE ADK (Agent Development Kit)                                 │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │   LLM Agent  │  │   Tools      │  │   Memory     │              │   │
│  │  │  (Gemini)    │  │  (Search,    │  │  (Contexto)  │              │   │
│  │  │              │  │   APIs...)   │  │              │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│     Retorna:                       │                                        │
│     • Mapeia response ADK → Bibha  │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Response Format (Bibha-compatible):                                │   │
│  │  {                                                                  │   │
│  │    "text": "Resposta do agente...",                                 │   │
│  │    "sessionId": "sess-123-abc",                                     │   │
│  │    "chatId": "chat-xyz"                                             │   │
│  │  }                                                                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ HTTPS Response
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  BIBHA.AI (De volta para orquestrar)                                        │
│  • Recebe resposta do nosso adapter                                         │
│  • Formata se necessário                                                    │
│  • Envia de volta ao canal do usuário (WhatsApp, Web, etc)                  │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
                              USUÁRIO FINAL
```

---

## 🎭 Papéis na Arquitetura

### Bibha.ai = **Orquestradora de Canais**
- ✅ Recebe mensagens de WhatsApp, Web, Telefone
- ✅ Gerencia sessões de conversação
- ✅ Roteia entre diferentes agentes
- ✅ Mantém histórico unificado
- ✅ Fornece interface visual (drag-and-drop)

### Easy Agent Builder = **Motor de Agentes Inteligentes**
- ✅ Processamento com Google Gemini/Vertex AI
- ✅ Tools customizadas (CRM, APIs internas)
- ✅ Workflows complexos multi-agent
- ✅ Integração nativa GCP
- ✅ Código Python quando necessário

---

## 🔄 Fluxo Real de uma Conversa

### Cenário: Cliente pergunta sobre preços via WhatsApp

```
1. CLIENTE envia mensagem no WhatsApp
   "Oi, qual o preço do plano Enterprise?"

2. BIBHA recebe a mensagem
   • Identifica: canal=whatsapp, numero=+55...
   • Cria/mantém sessão: sessionId="sess-abc-123"
   • Verifica: qual agente deve responder?

3. BIBHA decide chamar nosso agente (via HTTP Tool)
   POST https://adapter.run.app/api/v1/prediction/vendas
   {
     "question": "Oi, qual o preço do plano Enterprise?",
     "sessionId": "sess-abc-123",
     "chatflowId": "vendas",
     "metadata": {
       "channel": "whatsapp",
       "phone": "+551199999..."
     }
   }

4. NOSSO ADAPTER recebe e processa
   • Cria sessão ADK com ID "sess-abc-123"
   • Executa agente de vendas
   • Agente pode:
     - Consultar CRM (tool customizada)
     - Buscar preços atualizados
     - Aplicar regras de negócio
   • Gera resposta

5. NOSSO ADAPTER retorna para Bibha
   {
     "text": "Olá! O plano Enterprise custa R$ 5.000/mês...",
     "sessionId": "sess-abc-123",
     "chatId": "chat-vendas-001"
   }

6. BIBHA recebe a resposta
   • Formata se necessário
   • Adiciona ao histórico da conversa
   • Envia de volta ao WhatsApp do cliente

7. CLIENTE recebe resposta no WhatsApp
   "Olá! O plano Enterprise custa R$ 5.000/mês..."
```

---

## 🛠️ O que foi Implementado

### ✅ Código Pronto (Na pasta `easy_agent_builder/`)

1. **`src/agent_builder/bibha_adapter_real.py`**
   - Classe `BibhaExternalAdapter`
   - Recebe requests no formato Bibha
   - Processa via ADK
   - Retorna formato Bibha
   - Endpoints: `/api/v1/prediction/{chatflowId}`, `/webhook/bibha`, `/health`

2. **`examples/10_bibha_integration_real.py`**
   - Exemplo completo de uso
   - Agente de vendas integrado
   - Instruções de deploy

3. **`docs/BIBHA_INTEGRATION_GUIDE.md`**
   - Guia passo a passo
   - Configuração na interface Bibha
   - Troubleshooting

---

## 🚀 Como Usar (Resumido)

### Opção 1: Agente YAML (Ultra Low-Code)
```bash
# 1. Criar agente YAML
eab create agent vendedor_whatsapp --type llm

# 2. Deploy do adapter
gcloud run deploy bibha-adapter \
  --set-env-vars BIBHA_API_KEY=bah-sk-xxx \
  --set-env-vars BIBHA_API_HOST=https://sua.bibha.ai

# 3. Configurar HTTP Tool na Bibha
# (Na interface web da Bibha, adicionar HTTP Tool apontando para seu adapter)
```

### Opção 2: Agente com Código (Full Power)
```python
# src/agents/vendedor_pro/agent.py
from google.adk.agents import LlmAgent
from tools import consultar_crm, calcular_desconto

agent = LlmAgent(
    name="vendedor_pro",
    tools=[consultar_crm, calcular_desconto],  # Suas integrações!
    instruction="..."
)
```

---

## 📊 Comparativo: Bibha sozinha vs Bibha + ADK

| Funcionalidade | Bibha Sozinha | Bibha + ADK |
|----------------|---------------|-------------|
| **Chatbots simples** | ✅ Fácil | ✅ Fácil |
| **Integração CRM** | ⚠️ Via tools | ✅ Tools Python robustas |
| **Lógica de negócio complexa** | ⚠️ Limitado | ✅ Código Python completo |
| **Multi-agent avançado** | ✅ Visual | ✅ Código + Visual |
| **Modelos Google/Gemini** | ⚠️ Via API | ✅ Nativo (Vertex AI) |
| **Deploy GCP** | ⚠️ Genérico | ✅ Nativo (Cloud Run, Agent Engine) |
| **RAG com Vertex AI** | ❌ | ✅ Integrado |
| **Equipe técnica Google** | ⚠️ Aprende Bibha | ✅ Usa ADK (padrão Google) |

---

## 🎯 Quando usar esta integração?

### ✅ Use Bibha + ADK quando:
- Precisa de **múltiplos canais** (WhatsApp, Web, Telefone)
- Quer **orquestração visual** (drag-and-drop)
- Precisa de **tools complexas** em Python (CRM, ERP, APIs internas)
- Quer usar **Google Gemini/Vertex AI** nativamente
- Precisa de **workflows multi-agent** sofisticados

### ❌ Use só Bibha quando:
- Chatbots simples com tools básicas
- Não precisa de integrações complexas
- Equipe não tem skills Python

### ❌ Use só ADK quando:
- Só precisa de API/Web (sem WhatsApp)
- Quer controle total do código
- Não precisa de interface visual para orquestração

---

## ⚙️ Configuração Mínima para Funcionar

### 1. Na Bibha.ai (Interface Web)
```
1. Acesse: Utils → API Keys → Create API Key
2. Copie: bah-sk-sua-chave
3. Anote: chatflowId (ex: "vendas-flow-001")
```

### 2. No Nosso Adapter (Deploy)
```bash
gcloud run deploy bibha-adapter \
  --set-env-vars BIBHA_API_KEY=bah-sk-sua-chave \
  --set-env-vars BIBHA_API_HOST=https://sua-conta.bibha.ai \
  --set-env-vars BIBHA_CHATFLOW_ID=vendas-flow-001
```

### 3. Na Bibha.ai (HTTP Tool)
```
1. Acesse: Utils → Toolkit → Add Tool
2. Configure:
   - Name: "ADK Agent Bridge"
   - Method: POST
   - URL: https://bibha-adapter-xxxxx.run.app/api/v1/prediction/{{chatflowId}}
   - Body: {"question": "{{user_message}}", "sessionId": "{{session_id}}"}
3. Salve
```

### 4. Teste
```
Abra o chat no WhatsApp/Web da Bibha e envie uma mensagem!
```

---

## 📋 Status da Implementação

| Componente | Status | Arquivo |
|------------|--------|---------|
| Adapter Bibha | ✅ Pronto | `bibha_adapter_real.py` |
| Exemplo de uso | ✅ Pronto | `10_bibha_integration_real.py` |
| Documentação | ✅ Pronta | `BIBHA_INTEGRATION_GUIDE.md` |
| Deploy Cloud Run | ✅ Script pronto | `setup_test.sh` |
| Testes | ⚠️ Precisa de conta Bibha real | - |

---

## ❓ Resumo para Stakeholders

> **"A Bibha.ai atua como o 'receptionist' que recebe clientes em múltiplos canais (WhatsApp, Web, Telefone) e os direciona. O Easy Agent Builder (ADK) é o 'especialista' que processa as solicitações complexas usando Google AI e integrações internas. Juntos, formam um sistema completo: Bibha gerencia a interface e canais, ADK entrega a inteligência."**

---

**Dúvidas sobre a arquitetura ou próximos passos?** 🤔
