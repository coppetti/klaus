# 📁 Estrutura do Projeto

```
easy_agent_builder/
│
├── 📦 FRAMEWORK CORE
│   └── src/agent_builder/
│       ├── __init__.py              # Exports principais
│       ├── cli.py                   # CLI: eab create, eab deploy
│       ├── registry.py              # Discovery e registro de agentes
│       ├── orchestration.py         # Padrões: Router, Sequential, Parallel
│       ├── deployer.py              # Deploy GCP (Cloud Run, Agent Engine)
│       ├── integration_abstract.py  # Base para integrações externas
│       └── templates/               # Templates de código
│
├── 🤖 AGENTES (exemplos incluídos)
│   └── src/agents/
│       ├── root_agent.py            # Router multi-agent
│       ├── meu_chatbot/             # Criado via setup_test.sh
│       ├── search/
│       ├── data/
│       └── api/
│
├── ⚙️ CONFIGURAÇÃO
│   ├── config/
│   │   ├── agents.yaml              # Definições declarativas
│   │   └── deployment.yaml          # Config GCP
│   └── .env                         # Variáveis de ambiente (não commite!)
│
├── 📚 DOCUMENTAÇÃO
│   ├── README.md                    # Visão geral
│   ├── QUICKSTART.md                # Guia rápido teste local
│   ├── ARCHITECTURE_ANALYSIS.md     # Análise arquitetural
│   ├── ARCHITECTURE_PRIVACY.md      # Privacidade e integração
│   ├── INTEGRATION_GUIDE.md         # Guia de integração externa
│   └── docs/DEPLOYMENT.md           # Guia de deploy GCP
│
├── 🧪 TESTES
│   ├── tests/                       # Testes unitários
│   ├── tests_local/                 # Testes locais (criado dinamicamente)
│   └── test_local.py                # Script de teste interativo
│
├── 🚀 DEPLOYMENT
│   ├── deployment/
│   │   ├── Dockerfile
│   │   ├── cloudbuild.yaml          # CI/CD completo
│   │   └── terraform/               # IaC (futuro)
│   └── setup_test.sh                # Setup automático local
│
├── 📖 EXEMPLOS
│   └── examples/
│       ├── 01_basic_agent.py
│       ├── 02_router_pattern.py
│       ├── 03_sequential_workflow.py
│       ├── 04_parallel_workflow.py
│       ├── 05_bibha_integration.py  # Template genérico
│       └── 07_private_integration_template.py  # Para você customizar
│
└── 📋 CONFIGURAÇÃO DO PROJETO
    ├── pyproject.toml               # Dependências e metadados
    ├── .env.example                 # Template de variáveis
    └── PROJECT_STRUCTURE.md         # Este arquivo
```

## 🎯 Fluxo de Uso

### 1. Setup Inicial
```bash
./setup_test.sh          # Instala tudo e cria agente exemplo
```

### 2. Desenvolvimento Local
```bash
export GOOGLE_CLOUD_PROJECT=seu-projeto
python test_local.py     # Chat interativo
```

### 3. Criar Novos Agentes
```bash
eab create agent novo_agente --type llm
eab create workflow pipeline --type sequential
```

### 4. Deploy
```bash
eab deploy --env production --agent meu_chatbot
```

## 🔒 Arquivos Sensíveis (não commite)

```
.env                          # Secrets
private/                      # Implementações privadas (Bibha)
src/agents/meu_chatbot/       # Criado localmente
tests_local/                  # Testes locais
```

## 📊 Estatísticas

- **31 arquivos** de código e configuração
- **232KB** total
- **Python 3.11+**
- **GCP Ready** (Vertex AI, Cloud Run)
