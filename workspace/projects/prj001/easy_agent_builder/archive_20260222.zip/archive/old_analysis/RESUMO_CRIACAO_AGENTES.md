# 🎯 Resumo: 3 Formas de Criar Agentes

## Overview

O Easy Agent Builder suporta **três níveis de complexidade**:

| Nível | Quando Usar | Tempo | Conhecimento |
|-------|-------------|-------|--------------|
| **1. YAML Puro** | 80% dos casos | 2 min | Mínimo |
| **2. Híbrido** | Precisa de tools custom | 10 min | Básico |
| **3. Código Full** | Lógica complexa | 30 min | Python |

---

## 1️⃣ YAML Puro (Ultra Low-Code)

### Para quem é:
- Product Managers
- Analistas de Negócio
- Prototipagem rápida

### Exemplo:
```yaml
# agents/meu_bot.yaml
name: meu_bot
type: llm
model: gemini-2.0-flash-exp

description: Assistente virtual amigável

instruction: |
  Você é um assistente prestativo.
  Responda sempre em português.

tools:
  - google_search

temperature: 0.7
```

### Comandos:
```bash
# Criar
eab create agent meu_bot --type llm

# Validar
eab validate agents/meu_bot.yaml

# Rodar
eab run agents/meu_bot.yaml

# Deploy
eab deploy --yaml agents/meu_bot.yaml
```

### Limitações:
- ❌ Sem lógica customizada
- ❌ Sem acesso a APIs internas
- ❌ Sem integrações complexas

---

## 2️⃣ Híbrido (YAML + Código)

### Para quem é:
- Devs que querem velocidade
- Tools customizadas simples
- Integrações específicas

### Exemplo:

**YAML (comportamento):**
```yaml
# agents/suporte.yaml
name: suporte
instruction: |
  Consulte o CRM antes de responder.
tools:
  - google_search
  - consultar_crm  # Tool do código
```

**Python (tool customizada):**
```python
# src/agents/suporte/tools.py
from google.adk.tools import tool

@tool
def consultar_crm(cliente_id: str):
    """Consulta API interna de CRM"""
    response = requests.get(f"https://api.company.com/crm/{cliente_id}")
    return response.json()
```

**Registro (agente):**
```python
# src/agents/suporte/agent.py
from google.adk.agents import LlmAgent
from google.adk.tools import google_search
from .tools import consultar_crm

agent = LlmAgent(
    name="suporte",
    instruction="...",
    tools=[google_search, consultar_crm]  # Mix!
)
```

### Comandos:
```bash
# Criar estrutura híbrida
eab create agent suporte --type llm --code

# Editar tools
vim src/agents/suporte/tools.py

# Testar
eab test suporte --interactive
```

### Vantagens:
- ✅ PM edita instruções (YAML)
- ✅ Dev mantém tools (Python)
- ✅ Separacão de responsabilidades
- ✅ Reutilização de tools

---

## 3️⃣ Código Full (Python)

### Para quem é:
- Casos complexos
- Lógica de negócio pesada
- Workflows multi-agent avançados

### Exemplo Completo:
```python
# src/agents/vendedor_pro/agent.py

from google.adk.agents import LlmAgent, SequentialAgent
from google.adk.tools import tool, google_search

# Tools complexas
@tool
def calcular_proposta(valor: float, segmento: str):
    """Lógica de pricing com regras de negócio"""
    desconto = 0.15 if segmento == "Enterprise" else 0.05
    if valor > 100000:
        desconto += 0.10
    return {"final": valor * (1 - desconto)}

@tool
def consultar_pipeline(vendedor_id: str):
    """Integração Salesforce"""
    # Código complexo de integração
    pass

# Sub-agentes especialistas
qualificador = LlmAgent(
    name="qualificador",
    instruction="Qualifique leads...",
    tools=[consultar_pipeline]
)

negociador = LlmAgent(
    name="negociador",
    instruction="Negocie propostas...",
    tools=[calcular_proposta]
)

# Workflow sequencial
agent = SequentialAgent(
    name="vendedor_pro",
    sub_agents=[qualificador, negociador]
)
```

### Comandos:
```bash
# Criar com código
eab create agent vendedor_pro --type sequential --code

# Desenvolver
vim src/agents/vendedor_pro/agent.py

# Testar
python src/agents/vendedor_pro/agent.py

# Deploy
eab deploy --agent vendedor_pro
```

### Vantagens:
- ✅ Controle total
- ✅ Lógica complexa
- ✅ Testes unitários
- ✅ Versionamento granular

---

## 🔄 Comparativo Visual

### Cenário: Agente de Vendas

**YAML Puro:**
```yaml
name: vendedor_simples
instruction: Você é um vendedor. Apresente nossos produtos.
tools: [google_search]
```
*Capacidade: Busca info na web e responde*

**Híbrido:**
```yaml
# YAML
instruction: Consulte o CRM e personalize a oferta.
tools: [google_search, consultar_crm]
```
```python
# Python
@tool
def consultar_crm(id: str): ...
```
*Capacidade: Busca + Dados do cliente + Personalização*

**Código Full:**
```python
# Workflow completo com pricing dinâmico,
# aprovações, follow-up automático
sequential = SequentialAgent(...)
```
*Capacidade: Processo de vendas completo automatizado*

---

## 🎯 Guia de Decisão Rápida

```
Precisa integrar com sistema interno?
├── SIM → CÓDIGO (tool customizada)
└── NÃO →
    Precisa de lógica condicional complexa?
    ├── SIM → CÓDIGO
    └── NÃO →
        É apenas comportamento + tools prontas?
        ├── SIM → YAML
        └── NÃO → HÍBRIDO
```

---

## 📊 Exemplos por Cenário

| Cenário | Nível | Arquivo |
|---------|-------|---------|
| FAQ simples | YAML | `agents/faq.yaml` |
| Chatbot com busca | YAML | `agents/assistente.yaml` |
| Router de atendimento | YAML | `agents/router.yaml` |
| Suporte com CRM | Híbrido | `agents/suporte/` |
| Vendas com pricing | Código | `src/agents/vendedor_pro/` |
| Análise de dados | Código | `src/agents/analista/` |
| Workflow ETL | Código | `src/agents/etl_pipeline/` |

---

## 🚀 Quick Start por Nível

### Nível 1: YAML (2 minutos)
```bash
eab create agent teste --type llm
eab run agents/teste.yaml
```

### Nível 2: Híbrido (10 minutos)
```bash
eab create agent meu_agente --type llm --code
vim src/agents/meu_agente/tools.py  # Adicione tools
vim src/agents/meu_agente/agent.py  # Registre tools
eab test meu_agente --interactive
```

### Nível 3: Código Full (30 minutos)
```bash
eab create agent complexo --type sequential --code
vim src/agents/complexo/agent.py    # Implemente tudo
python src/agents/complexo/agent.py # Teste local
eab deploy --agent complexo
```

---

## 💡 Dicas

1. **Sempre comece com YAML**
   - Se não for suficiente, evolua para híbrido
   - Só vá para código full se necessário

2. **Mantenha tools reutilizáveis**
   - CRM, ERP, APIs comuns → biblioteca de tools

3. **Documente as tools**
   - PMs precisam saber o que está disponível

4. **Versione por nível**
   - YAML: versione o arquivo
   - Código: use git normalmente

---

**Resumo: Comece simples (YAML), evolua conforme necessidade!**
